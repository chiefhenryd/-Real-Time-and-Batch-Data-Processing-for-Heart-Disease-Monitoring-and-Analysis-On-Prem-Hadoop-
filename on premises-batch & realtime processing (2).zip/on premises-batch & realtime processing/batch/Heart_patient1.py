from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, LongType
import pyspark.sql.functions as F

# Create a Spark session with configuration
spark = SparkSession.builder \
    .appName("Heart Disease Data Preprocessing") \
    .master("local[*]") \
    .getOrCreate()

# Define the schema explicitly
schema = StructType([
    StructField("PatientID", LongType(), nullable=True),
    StructField("HeartDisease", StringType(), nullable=True),
    StructField("BMI", DoubleType(), nullable=True),
    StructField("Smoking", StringType(), nullable=True),
    StructField("AlcoholDrinking", StringType(), nullable=True),
    StructField("Stroke", StringType(), nullable=True),
    StructField("PhysicalHealth", DoubleType(), nullable=True),
    StructField("MentalHealth", DoubleType(), nullable=True),
    StructField("Gender", StringType(), nullable=True),
    StructField("AgeCategory", StringType(), nullable=True),
    StructField("Diabetic", StringType(), nullable=True),
    StructField("GenHealth", StringType(), nullable=True),
    StructField("age", DoubleType(), nullable=True),
    StructField("cholesterol", DoubleType(), nullable=True),
    StructField("resting_ecg", StringType(), nullable=True),
    StructField("SystolicBP", DoubleType(), nullable=True),
    StructField("DiastolicBP", DoubleType(), nullable=True),
    StructField("HeartRate", DoubleType(), nullable=True),
    StructField("target", LongType(), nullable=True)
])

# Read the raw text data as CSV
df1 = spark.read.schema(schema).option("header", "false").csv("ukussept2024/Henry/raw/part1/part-m-00000")
df2 = spark.read.schema(schema).option("header", "false").csv("ukussept2024/Henry/raw/part2/part-m-00000")

# Merge the two DataFrames without losing records
merged_df = df1.unionByName(df2)


# Check for duplicates and drop them based on "PatientID"
# Data Cleaning Operations: Only remove exact duplicates and fill missing values
cleaned_df = merged_df.dropDuplicates() \
    .na.fill("Unknown", subset=["Gender", "AgeCategory", "Diabetic", "GenHealth"]) \
    .na.fill(0, subset=["BMI", "PhysicalHealth", "MentalHealth", "age", "cholesterol", "SystolicBP", "DiastolicBP", "HeartRate"])


# Normalize text fields: trimming and converting to lower case for consistency
cleaned_df = cleaned_df.withColumn("Gender", F.trim(F.lower(F.col("Gender")))) \
    .withColumn("AgeCategory", F.trim(F.lower(F.col("AgeCategory")))) \
    .withColumn("Diabetic", F.trim(F.lower(F.col("Diabetic")))) \
    .withColumn("GenHealth", F.trim(F.lower(F.col("GenHealth")))) \
    .withColumn("HeartDisease", F.trim(F.lower(F.col("HeartDisease"))))

# Show the first few rows of the cleaned DataFrame (optional)
cleaned_df.show(5)

# Write the cleaned DataFrame to a new location in HDFS as text files
cleaned_df.write \
    .mode("overwrite") \
    .option("header", False) \
    .csv("ukussept2024/Henry/staging/heart_data4")

# Stop the Spark session
spark.stop()


