from pyspark.sql import SparkSession
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pyspark.sql.types import StructType, StructField, StringType, LongType

# Create a Spark session
spark = SparkSession.builder \
    .appName("Heart Disease Analysis") \
    .enableHiveSupport() \
    .getOrCreate()

# File paths with headers
file_path_1 = "/home/ec2-user/q9/with_headers_000000_0"
file_path_2 = "/home/ec2-user/q9/with_headers_000001_0"

# Define the schema for the input data
schema = StructType([
    StructField("patientid", LongType(), True),
    StructField("gender", StringType(), True),
    StructField("agecategory", StringType(), True)
])

# Read data from the files into DataFrames
df1 = spark.read.csv(file_path_1, header=True, schema=schema)
df2 = spark.read.csv(file_path_2, header=True, schema=schema)

# Combine the two DataFrames
combined_df = df1.union(df2)

# Convert the Spark DataFrame to a Pandas DataFrame for easier plotting
pandas_df = combined_df.toPandas()

# Visualization 1: Distribution of Age Categories
plt.figure(figsize=(10, 6))
sns.countplot(data=pandas_df, x='agecategory', order=pandas_df['agecategory'].value_counts().index)
plt.xticks(rotation=45)
plt.title('Distribution of Age Categories')
plt.xlabel('Age Category')
plt.ylabel('Count of Records')
plt.tight_layout()
plt.savefig("/home/ec2-user/UKUSSeptBatch/Henry/BD_Project/Data_Preprocessing/age_category_distribution.png")  # Save the plot as a PNG file
plt.close()  # Close the figure to free up memory

# Visualization 2: Gender Distribution
plt.figure(figsize=(6, 4))
sns.countplot(data=pandas_df, x='gender')
plt.title('Gender Distribution')
plt.xlabel('Gender')
plt.ylabel('Count of Records')
plt.tight_layout()
plt.savefig("/home/ec2-user/UKUSSeptBatch/Henry/BD_Project/Data_Preprocessing/gender_distribution.png")  # Save the plot as a PNG file
plt.close()  # Close the figure to free up memory

# Visualization 3: Number of Patients per Age Category
age_category_counts = pandas_df.groupby('agecategory')['patientid'].nunique().reset_index()
age_category_counts = age_category_counts.sort_values('patientid', ascending=False)

plt.figure(figsize=(10, 6))
sns.barplot(data=age_category_counts, x='agecategory', y='patientid', order=age_category_counts['agecategory'])
plt.xticks(rotation=45)
plt.title('Number of Unique Patients per Age Category')
plt.xlabel('Age Category')
plt.ylabel('Number of Unique Patients')
plt.tight_layout()
plt.savefig("/home/ec2-user/UKUSSeptBatch/Henry/BD_Project/Data_Preprocessing/unique_patients_age_category.png")  # Save the plot as a PNG file
plt.close()  # Close the figure to free up memory

# Stop the Spark session when done
spark.stop()
