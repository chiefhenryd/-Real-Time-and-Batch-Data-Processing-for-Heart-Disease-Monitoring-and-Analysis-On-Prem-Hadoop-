from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
import matplotlib.pyplot as plt

# Initialize Spark session
spark = SparkSession.builder \
    .appName("Heart Disease Analysis") \
    .getOrCreate()

# Define the schema for the input data
schema = StructType([
    StructField("dl.smoking", StringType(), True),
    StructField("dl.alcoholdrinking", StringType(), True),
    StructField("count_with_heart_disease", IntegerType(), True)
])

# Load the dataset with the defined schema
file_path = "/home/ec2-user/UKUSSeptBatch/Henry/BD_Project/Data_Preprocessing/combined_patient_data.csv/q7.csv"
df = spark.read.csv(file_path, header=True, schema=schema)

# Print the schema to confirm column names
df.printSchema()
df.show(5)  # Display the first 5 rows

# Rename columns to remove the 'dl.' prefix
df = df.withColumnRenamed("dl.smoking", "smoking") \
       .withColumnRenamed("dl.alcoholdrinking", "alcoholdrinking")

# Group by the renamed columns
grouped_df = df.groupBy("smoking", "alcoholdrinking").agg({"count_with_heart_disease": "sum"})

# Collect the results to a Pandas DataFrame for visualization
pandas_df = grouped_df.toPandas()

# Check the contents of the pandas DataFrame
print(pandas_df)

# Bar plot
plt.figure(figsize=(10, 6))
bar_plot = pandas_df.pivot(index='smoking', columns='alcoholdrinking', values='sum(count_with_heart_disease)')
bar_plot.plot(kind='bar', stacked=True)
plt.title('Count of Heart Disease by Smoking and Alcohol Drinking')
plt.xlabel('Smoking Status')
plt.ylabel('Count with Heart Disease')
plt.xticks(rotation=0)
plt.legend(title='Alcohol Drinking')
plt.tight_layout()

# Save the bar plot as a PNG file
plt.savefig('/home/ec2-user/UKUSSeptBatch/Henry/BD_Project/Data_Preprocessing/bar_plot_heart_disease.png')
plt.close()  # Close the plot to free memory

# Pie chart
plt.figure(figsize=(8, 8))
total_counts = df.groupBy("smoking").agg({"count_with_heart_disease": "sum"}).toPandas()
plt.pie(total_counts['sum(count_with_heart_disease)'], labels=total_counts['smoking'], autopct='%1.1f%%', startangle=90)
plt.title('Distribution of Heart Disease by Smoking Status')
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

# Save the pie chart as a PNG file
plt.savefig('/home/ec2-user/UKUSSeptBatch/Henry/BD_Project/Data_Preprocessing/pie_chart_heart_disease.png')
plt.close()  # Close the plot to free memory

# Stop the Spark session
spark.stop()
