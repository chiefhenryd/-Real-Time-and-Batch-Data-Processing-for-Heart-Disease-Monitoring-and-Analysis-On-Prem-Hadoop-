from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, IntegerType, DoubleType, StringType
from pyspark.sql.functions import from_json, col, when, lit

# Create a Spark session
spark = SparkSession.builder \
    .appName("HeartRateMonitoring") \
    .getOrCreate()

# Set Kafka parameters
kafka_brokers = "ip-172-31-13-101.eu-west-2.compute.internal:9092"
topic = "Henry_sept2024"

# Define the schema for the incoming JSON data
schema = StructType([
    StructField("patientid", IntegerType(), True),
    StructField("heartrate", DoubleType(), True),
    StructField("systolicbp", DoubleType(), True),
    StructField("diastolicbp", DoubleType(), True),
    StructField("timestamp", StringType(), True)
])

# Create DataFrame representing the stream of input lines from Kafka
df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", kafka_brokers) \
    .option("subscribe", topic) \
    .load()

# Parse the JSON data
parsed_df = df.selectExpr("CAST(value AS STRING) as json") \
    .select(from_json("json", schema).alias("data")) \
    .select("data.*")

# Add an alert column for high blood pressure
alert_df = parsed_df.withColumn(
    "alert",
    when((col("systolicbp") > 130) | (col("diastolicbp") > 80), lit("High blood pressure detected"))
    .otherwise(lit("Normal blood pressure"))  # Indicate normal blood pressure explicitly
)

# Write the complete data with alerts to the console
query = alert_df.writeStream \
    .outputMode("append") \
    .format("console") \
    .option("truncate", "false") \
    .start()

# Await termination
query.awaitTermination()
