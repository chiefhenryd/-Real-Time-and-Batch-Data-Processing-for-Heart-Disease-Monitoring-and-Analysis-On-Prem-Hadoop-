from kafka import KafkaConsumer
import json

# Set up Kafka consumer
bootstrap_servers = 'ip-172-31-13-101.eu-west-2.compute.internal:9092'  # Adjust as necessary

# Create the Kafka consumer
consumer = KafkaConsumer(
    'Henry_sept2024',  # Topic to subscribe to
    bootstrap_servers=bootstrap_servers,
    enable_auto_commit=True,
    value_deserializer=lambda x: x.decode('utf-8'),  # Deserialize from UTF-8
    auto_offset_reset='earliest'  # Start reading from the earliest message
)

# Print message to indicate listening state
print("Listening for messages on topic 'Henry_sept2024'...")

# Consuming messages from Kafka
try:
    for message in consumer:
        # Print the raw message before processing
        raw_message = message.value
        print(f"Raw message received: {raw_message}")

        if not raw_message:  # Skip empty messages
            print("Received an empty message, skipping...")
            continue

        try:
            # Attempt to decode the JSON message
            decoded_message = json.loads(raw_message)
            print(f"Decoded JSON message: {decoded_message}")

            # Check for high blood pressure alerts
            systolic_bp = decoded_message.get("systolicbp")
            diastolic_bp = decoded_message.get("diastolicbp")

            # Define thresholds for high blood pressure
            if systolic_bp > 130 or diastolic_bp > 80:
                print(f"Alert! High blood pressure detected: Systolic: {systolic_bp}, Diastolic: {diastolic_bp}")

        except json.JSONDecodeError as e:
            print(f"JSON decoding error: {e}. This error occurred while decoding: {raw_message}")

except KeyboardInterrupt:
    print("Consumer stopped manually.")
finally:
    consumer.close()
