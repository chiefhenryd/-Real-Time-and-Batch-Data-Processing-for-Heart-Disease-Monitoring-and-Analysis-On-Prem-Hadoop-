from kafka import KafkaProducer
import json
import time
import random
from datetime import datetime
import pandas as pd

# Load Patient IDs from the CSV file
file_path = "/home/ec2-user/cleaned_heart_data.csv/part-00000-fa66070f-8a77-41c9-8019-bc6585f20158-c000.csv"
df = pd.read_csv(file_path)

# Set up Kafka producer
producer = KafkaProducer(
    bootstrap_servers='ip-172-31-13-101.eu-west-2.compute.internal:9092',  # Adjust as necessary
    value_serializer=lambda v: json.dumps(v).encode('utf-8')  # Serialize as JSON
)

# Generate fake data for patient records
def generate_patient_data(patient_id):
    return {
        "patientid": patient_id,  # Patient ID from the CSV file
        "heartrate": round(random.uniform(60.0, 120.0), 1),  # Random heart rate
        "systolicbp": round(random.uniform(90.0, 180.0), 1),  # Random systolic blood pressure
        "diastolicbp": round(random.uniform(60.0, 120.0), 1),  # Random diastolic blood pressure
        "timestamp": datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')  # Current timestamp
    }

# Continuous data production loop
try:
    while True:
        # Send data for each patient loaded from the CSV file
        for patient_id in df['Patient ID']:
            patient_data = generate_patient_data(patient_id)
            producer.send('Henry_sept2024', patient_data)
            print(f"Sent patient data: {patient_data}")
        
        # Sleep for a specified interval before sending the next batch
        time.sleep(10)  # Adjust the interval as needed (e.g., every 10 seconds)

except KeyboardInterrupt:
    print("Producer stopped manually.")
finally:
    # Ensure all messages are sent
    producer.flush()
    producer.close()
